
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';

import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';

import AddStudent from './pages/AddStudent';
import EditStudent from './pages/EditStudent';
import Dashboard from './pages/Dashboard';
import Students from './pages/Students';
import StudentDetails from './pages/StudentDetails';
import Jobs from './pages/Jobs';
import Applications from './pages/Applications';
import NotFound from './pages/NotFound';
import Login from './pages/Login';
import AcademicRecords from './pages/AcademicRecords';
import AddAcademicRecord from './pages/AddAcademicRecord';
import Skills from './pages/Skills';
import Certifications from './pages/Certifications';
import Companies from './pages/Companies';
import PlacementDrives from './pages/PlacementDrives';
import Eligibility from './pages/Eligibility';
import Interviews from './pages/Interviews';
import Selections from './pages/Selections';
import SubjectSelection from './pages/SubjectSelection';
import SubjectConfiguration from './pages/SubjectConfiguration';

import AdminDashboard from './pages/AdminDashboard';
import TeacherDashboard from './pages/TeacherDashboard';
import StudentDashboard from './pages/StudentDashboard';

function App() {
    return (
        <BrowserRouter>
            <Routes>
                {/* Public route */}
                <Route path="/login" element={<Login />} />

                {/* Admin-only dashboard */}
                <Route element={<ProtectedRoute allowedRoles={['Admin']} />}>
                    <Route path="/admin-dashboard" element={<Layout />}>
                        <Route index element={<AdminDashboard />} />
                    </Route>
                </Route>

                {/* Teacher-only dashboard */}
                <Route element={<ProtectedRoute allowedRoles={['Teacher']} />}>
                    <Route path="/teacher-dashboard" element={<Layout />}>
                        <Route index element={<TeacherDashboard />} />
                    </Route>
                </Route>

                {/* Student-only dashboard */}
                <Route element={<ProtectedRoute allowedRoles={['Student']} />}>
                    <Route path="/student-dashboard" element={<Layout />}>
                        <Route index element={<StudentDashboard />} />
                    </Route>
                </Route>

                {/* General protected application pages */}
                <Route element={<ProtectedRoute />}>
                    <Route path="/" element={<Layout />}>
                        <Route index element={<Dashboard />} />

                        <Route path="students" element={<Students />} />
                        <Route
                            path="students/:studentId"
                            element={<StudentDetails />}
                        />
                        <Route
                            path="students/:id/edit"
                            element={<EditStudent />}
                        />
                        <Route path="students/add" element={<AddStudent />} />

                        <Route path="jobs" element={<Jobs />} />
                        <Route path="applications" element={<Applications />} />

                        <Route
                            path="academic-records"
                            element={<AcademicRecords />}
                        />
                        <Route
                            path="academic-records/add"
                            element={<AddAcademicRecord />}
                        />

                        <Route path="skills" element={<Skills />} />
                        <Route
                            path="certifications"
                            element={<Certifications />}
                        />
                        <Route element={<ProtectedRoute allowedRoles={['Admin']} />}>
                        <Route path="companies" element={<Companies />} />
                        </Route>
                        <Route element={<ProtectedRoute allowedRoles={['Admin']} />}>
                        <Route path="subject-configuration" element={<SubjectConfiguration />}
                        />
                        </Route>
                        <Route
                            path="placement-drives"
                            element={<PlacementDrives />}
                        />
                        <Route path="eligibility" element={<Eligibility />} />
                        <Route path="interviews" element={<Interviews />} />
                        <Route path="selections" element={<Selections />} />
                        <Route path="subject-selection" element={<SubjectSelection />}/>

                        <Route path="*" element={<NotFound />} />
                    </Route>
                </Route>
            </Routes>
        </BrowserRouter>
    );
}

export default App;
