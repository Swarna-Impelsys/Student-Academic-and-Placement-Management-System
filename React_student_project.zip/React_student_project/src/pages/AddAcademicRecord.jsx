
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    getStudents,
    getSubjects,
    createAcademicRecord,
} from '../services/studentService';
import useApi from '../hooks/useApi';
import './AcademicRecords.css';

function AddAcademicRecord() {
    const navigate = useNavigate();

    const [students, setStudents] = useState([]);
    const [subjects, setSubjects] = useState([]);

    const [form, setForm] = useState({
        student: '',
        semester: '',
        subject: '',
        marks: '',
        attendance: '',
        backlog: false,
    });

    const { loading, error, setError, execute } = useApi();
    const [success, setSuccess] = useState('');

    useEffect(() => {
        async function loadOptions() {
            try {
                const [studentData, subjectData] = await Promise.all([
                    getStudents(),
                    getSubjects(),
                ]);

                setStudents(
                    Array.isArray(studentData)
                        ? studentData
                        : studentData.results ?? []
                );

                setSubjects(
                    Array.isArray(subjectData)
                        ? subjectData
                        : subjectData.results ?? []
                );
            } catch (err) {
                console.error('Failed to load form options:', err);
            }
        }

        loadOptions();
    }, []);

    function handleChange(event) {
        const { name, value, checked, type } = event.target;

        setForm((previous) => ({
            ...previous,
            [name]: type === 'checkbox' ? checked : value,
        }));
    }

    async function handleSubmit(event) {
        event.preventDefault();
        setError('');
        setSuccess('');

        try {
            await execute(() =>
                createAcademicRecord({
                    student: Number(form.student),
                    semester: Number(form.semester),
                    subject: Number(form.subject),
                    marks: Number(form.marks),
                    attendance: Number(form.attendance),
                    backlog: form.backlog,
                })
            );

            setSuccess('Academic record created successfully!');

            setTimeout(() => {
                navigate('/academic-records');
            }, 1000);
        } catch {
            // The useApi hook displays the API error.
        }
    }

    return (
        <div className="add-academic-record">
            <h2>Add Academic Record</h2>
            <p>Enter the student's academic information below.</p>

            {error && <p role="alert">{error}</p>}
            {success && <p role="status">{success}</p>}

            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="student">Student</label>
                    <select
                        id="student"
                        name="student"
                        value={form.student}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select student</option>

                        {students.map((item) => (
                            <option key={item.id} value={item.id}>
                                {item.Name} (ID: {item.id})
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label htmlFor="semester">Semester</label>
                    <input
                        id="semester"
                        name="semester"
                        type="number"
                        min="1"
                        value={form.semester}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label htmlFor="subject">Subject</label>
                    <select
                        id="subject"
                        name="subject"
                        value={form.subject}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select subject</option>

                        {subjects.map((item) => (
                            <option key={item.id} value={item.id}>
                                {item.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label htmlFor="marks">Marks (0–100)</label>
                    <input
                        id="marks"
                        name="marks"
                        type="number"
                        min="0"
                        max="100"
                        step="any"
                        value={form.marks}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label htmlFor="attendance">Attendance (0–100%)</label>
                    <input
                        id="attendance"
                        name="attendance"
                        type="number"
                        min="0"
                        max="100"
                        step="any"
                        value={form.attendance}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label>
                        <input
                            name="backlog"
                            type="checkbox"
                            checked={form.backlog}
                            onChange={handleChange}
                        />
                        Has backlog
                    </label>
                </div>

                <button type="submit" disabled={loading}>
                    {loading ? 'Saving...' : 'Save Academic Record'}
                </button>

                <button
                    type="button"
                    onClick={() => navigate('/academic-records')}
                    disabled={loading}
                >
                    Cancel
                </button>
            </form>
        </div>
    );
}

export default AddAcademicRecord;
