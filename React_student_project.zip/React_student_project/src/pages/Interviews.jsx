
import { useEffect, useState } from 'react';
import { getInterviews, createInterview, updateInterview, deleteInterview } from '../services/interviewService';
import { getApplications } from '../services/applicationService';
import { getStudents } from '../services/studentService';
import { getJobs } from '../services/jobService';
import '../App.css';

const emptyForm = {
    application: '',
    interview_date: '',
    interview_time: '',
    interview_type: 'online',
    location: '',
    meeting_link: '',
    status: 'scheduled',
    feedback: '',
};

function getList(data, key) {
    if (Array.isArray(data)) return data;
    return data?.results || data?.[key] || data?.data || [];
}

function Interviews() {
    const [interviews, setInterviews] = useState([]);
    const [applications, setApplications] = useState([]);
    const [students, setStudents] = useState([]);
    const [jobs, setJobs] = useState([]);

    const [form, setForm] = useState(emptyForm);
    const [editingId, setEditingId] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    async function loadData() {
        setLoading(true);
        setError('');

        try {
            const [interviewData, applicationData, studentData, jobData] =
                await Promise.all([
                    getInterviews(),
                    getApplications(),
                    getStudents(),
                    getJobs(),
                ]);

            setInterviews(getList(interviewData, 'interviews'));
            setApplications(getList(applicationData, 'applications'));
            setStudents(getList(studentData, 'students'));
            setJobs(getList(jobData, 'jobs'));
        } catch (err) {
            console.error('Interview loading error:', err.response?.data || err);
            setError(
                err.response?.data?.detail ||
                err.response?.data?.error ||
                'Could not load interview data. Check your backend and login.'
            );
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        loadData();
    }, []);

    function handleChange(event) {
        const { name, value } = event.target;

        setForm((previous) => ({
            ...previous,
            [name]: value,
            ...(name === 'interview_type'
                ? {
                    location: value === 'online' ? '' : previous.location,
                    meeting_link: value === 'offline' ? '' : previous.meeting_link,
                }
                : {}),
        }));
    }

    function resetForm() {
        setForm(emptyForm);
        setEditingId(null);
    }

    async function handleSubmit(event) {
        event.preventDefault();
        setError('');
        setSuccess('');

        if (form.interview_type === 'online' && !form.meeting_link.trim()) {
            setError('Meeting link is required for an online interview.');
            return;
        }

        if (form.interview_type === 'offline' && !form.location.trim()) {
            setError('Location is required for an offline interview.');
            return;
        }

        const payload = {
            application: Number(form.application),
            interview_date: form.interview_date,
            interview_time: form.interview_time,
            interview_type: form.interview_type,
            location: form.location.trim() || null,
            meeting_link: form.meeting_link.trim() || null,
            status: form.status,
            feedback: form.feedback.trim() || null,
        };

        setSaving(true);

        try {
            if (editingId) {
                await updateInterview(editingId, payload);
                setSuccess('Interview updated successfully.');
            } else {
                await createInterview(payload);
                setSuccess('Interview scheduled successfully.');
            }

            resetForm();
            await loadData();
        } catch (err) {
            console.error('Interview save error:', err.response?.data || err);

            const data = err.response?.data;
            const message = data
                ? Object.entries(data)
                    .map(([field, messages]) =>
                        `${field}: ${Array.isArray(messages) ? messages.join(', ') : messages}`
                    )
                    .join(' | ')
                : 'Could not save the interview. Please try again.';

            setError(message);
        } finally {
            setSaving(false);
        }
    }

    function startEdit(interview) {
        setEditingId(interview.id);
        setForm({
            application: String(interview.application ?? ''),
            interview_date: interview.interview_date || '',
            interview_time: interview.interview_time?.slice(0, 5) || '',
            interview_type: interview.interview_type || 'online',
            location: interview.location || '',
            meeting_link: interview.meeting_link || '',
            status: interview.status || 'scheduled',
            feedback: interview.feedback || '',
        });
        setError('');
        setSuccess('');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    async function handleDelete(id) {
        if (!window.confirm('Are you sure you want to delete this interview?')) {
            return;
        }

        setError('');
        setSuccess('');

        try {
            await deleteInterview(id);
            setSuccess('Interview deleted successfully.');

            if (editingId === id) resetForm();

            await loadData();
        } catch (err) {
            setError(
                err.response?.data?.detail ||
                err.response?.data?.error ||
                'Could not delete this interview.'
            );
        }
    }

    function getApplicationLabel(application) {
        const student = students.find(
            (item) => String(item.id) === String(application.student)
        );
        const job = jobs.find(
            (item) => String(item.id) === String(application.job)
        );

        const studentName = student?.Name || student?.name || `Student #${application.student}`;
        const jobTitle = job?.title || `Job #${application.job}`;

        return `${studentName} — ${jobTitle} (Application #${application.id})`;
    }

    function getApplicationDetails(applicationId) {
        const application = applications.find(
            (item) => String(item.id) === String(applicationId)
        );

        return application ? getApplicationLabel(application) : `Application #${applicationId}`;
    }

    function statusClass(status) {
        return `interview-status interview-status-${String(status || '').toLowerCase()}`;
    }

    return (
        <div className="interviews-page">
            <div className="interviews-header">
                <div>
                    <h2>Interview Management</h2>
                    <p>Schedule interviews and track their progress.</p>
                </div>

                <div className="interviews-count">
                    <span>Total interviews</span>
                    <strong>{interviews.length}</strong>
                </div>
            </div>

            {error && <div className="interviews-alert interviews-alert-error">{error}</div>}
            {success && <div className="interviews-alert interviews-alert-success">{success}</div>}

            <section className="interviews-card">
                <h3>{editingId ? 'Update Interview' : 'Schedule an Interview'}</h3>

                <form className="interviews-form" onSubmit={handleSubmit}>
                    <div className="interviews-field interviews-field-wide">
                        <label htmlFor="interview-application">Application</label>
                        <select
                            id="interview-application"
                            name="application"
                            value={form.application}
                            onChange={handleChange}
                            required
                        >
                            <option value="">Select an application</option>
                            {applications.map((application) => (
                                <option key={application.id} value={application.id}>
                                    {getApplicationLabel(application)}
                                </option>
                            ))}
                        </select>
                        {applications.length === 0 && (
                            <small>Create an application before scheduling an interview.</small>
                        )}
                    </div>

                    <div className="interviews-field">
                        <label htmlFor="interview-date">Interview date</label>
                        <input
                            id="interview-date"
                            name="interview_date"
                            type="date"
                            value={form.interview_date}
                            onChange={handleChange}
                            required
                        />
                    </div>

                    <div className="interviews-field">
                        <label htmlFor="interview-time">Interview time</label>
                        <input
                            id="interview-time"
                            name="interview_time"
                            type="time"
                            value={form.interview_time}
                            onChange={handleChange}
                            required
                        />
                    </div>

                    <div className="interviews-field">
                        <label htmlFor="interview-type">Interview type</label>
                        <select
                            id="interview-type"
                            name="interview_type"
                            value={form.interview_type}
                            onChange={handleChange}
                            required
                        >
                            <option value="online">Online</option>
                            <option value="offline">Offline</option>
                        </select>
                    </div>

                    {form.interview_type === 'online' ? (
                        <div className="interviews-field interviews-field-wide">
                            <label htmlFor="meeting-link">Meeting link</label>
                            <input
                                id="meeting-link"
                                name="meeting_link"
                                type="url"
                                placeholder="https://meet.example.com/..."
                                value={form.meeting_link}
                                onChange={handleChange}
                                required
                            />
                        </div>
                    ) : (
                        <div className="interviews-field interviews-field-wide">
                            <label htmlFor="interview-location">Interview location</label>
                            <input
                                id="interview-location"
                                name="location"
                                type="text"
                                placeholder="Enter office address"
                                value={form.location}
                                onChange={handleChange}
                                required
                            />
                        </div>
                    )}

                    <div className="interviews-field">
                        <label htmlFor="interview-status">Status</label>
                        <select
                            id="interview-status"
                            name="status"
                            value={form.status}
                            onChange={handleChange}
                            required
                        >
                            <option value="scheduled">Scheduled</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                            <option value="rescheduled">Rescheduled</option>
                        </select>
                    </div>

                    <div className="interviews-field interviews-field-wide">
                        <label htmlFor="interview-feedback">Feedback (optional)</label>
                        <textarea
                            id="interview-feedback"
                            name="feedback"
                            rows="3"
                            placeholder="Add interview feedback or notes"
                            value={form.feedback}
                            onChange={handleChange}
                        />
                    </div>

                    <div className="interviews-actions interviews-field-wide">
                        <button type="submit" disabled={saving || applications.length === 0}>
                            {saving
                                ? 'Saving...'
                                : editingId
                                    ? 'Update Interview'
                                    : 'Schedule Interview'}
                        </button>

                        {editingId && (
                            <button type="button" className="interviews-secondary-button" onClick={resetForm}>
                                Cancel Edit
                            </button>
                        )}
                    </div>
                </form>
            </section>

            <section className="interviews-card">
                <div className="interviews-list-header">
                    <h3>Interview Schedule</h3>
                    <button
                        type="button"
                        className="interviews-secondary-button"
                        onClick={loadData}
                        disabled={loading}
                    >
                        Refresh
                    </button>
                </div>

                {loading ? (
                    <p className="interviews-empty">Loading interviews...</p>
                ) : interviews.length === 0 ? (
                    <p className="interviews-empty">No interviews scheduled yet.</p>
                ) : (
                    <div className="interviews-table-wrapper">
                        <table className="interviews-table">
                            <thead>
                                <tr>
                                    <th>Application</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Type</th>
                                    <th>Details</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {interviews.map((interview) => (
                                    <tr key={interview.id}>
                                        <td>{getApplicationDetails(interview.application)}</td>
                                        <td>{interview.interview_date}</td>
                                        <td>{interview.interview_time?.slice(0, 5)}</td>
                                        <td>{interview.interview_type}</td>
                                        <td>
                                            {interview.interview_type === 'online' && interview.meeting_link ? (
                                                <a href={interview.meeting_link} target="_blank" rel="noreferrer">
                                                    Join link
                                                </a>
                                            ) : (
                                                interview.location || '—'
                                            )}
                                        </td>
                                        <td>
                                            <span className={statusClass(interview.status)}>
                                                {interview.status}
                                            </span>
                                        </td>
                                        <td>
                                            <div className="interviews-row-actions">
                                                <button type="button" onClick={() => startEdit(interview)}>
                                                    Edit
                                                </button>
                                                <button
                                                    type="button"
                                                    className="interviews-delete-button"
                                                    onClick={() => handleDelete(interview.id)}
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </section>
        </div>
    );
}

export default Interviews;
