
import { useEffect, useState } from 'react';
import {
    getApplications,
    createApplication,
} from '../services/applicationService';
import { getStudents } from '../services/studentService';
import { getJobs } from '../services/jobService';
import '../App.css';

function Applications() {
    const [applications, setApplications] = useState([]);
    const [students, setStudents] = useState([]);
    const [jobs, setJobs] = useState([]);

    const [studentId, setStudentId] = useState('');
    const [jobId, setJobId] = useState('');

    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    // Load applications, students, and jobs
    async function loadData() {
        setLoading(true);
        setError('');

        try {
            const [applicationData, studentData, jobData] =
                await Promise.all([
                    getApplications(),
                    getStudents(),
                    getJobs(),
                ]);

            // Handle applications response
            const applicationList = Array.isArray(applicationData)
                ? applicationData
                : applicationData.results ||
                  applicationData.applications ||
                  applicationData.data ||
                  [];

            setApplications(applicationList);

            // Show the complete student API response in the browser console
            console.log(
                'Full student API response:',
                JSON.stringify(studentData, null, 2)
            );

            // Handle different student response formats
            const studentList = Array.isArray(studentData)
                ? studentData
                : studentData.results ||
                  studentData.students ||
                  studentData.data ||
                  [];

            setStudents(studentList);

            // Handle jobs response
            const jobList = Array.isArray(jobData)
                ? jobData
                : jobData.results ||
                  jobData.jobs ||
                  jobData.data ||
                  [];

            setJobs(jobList);
        } catch (err) {
            console.error(
                'Applications API error:',
                err.response?.status,
                err.response?.data
            );

            setError(
                err.response?.data?.detail ||
                err.response?.data?.error ||
                'Unable to load applications. Please check the backend and your login.'
            );
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        loadData();
    }, []);

    // Submit an application
    async function handleSubmit(event) {
        event.preventDefault();

        setError('');
        setSuccess('');

        if (!studentId || !jobId) {
            setError('Please select a student and a job.');
            return;
        }

        setSubmitting(true);

        try {
            await createApplication(studentId, jobId);

            setSuccess('Application submitted successfully.');
            setStudentId('');
            setJobId('');

            await loadData();
        } catch (err) {
            console.error(
                'Application submission error:',
                err.response?.status,
                err.response?.data
            );

            const data = err.response?.data;

            const message =
                data?.detail ||
                data?.error ||
                data?.reason ||
                data?.non_field_errors?.[0] ||
                (typeof data === 'string' ? data : '') ||
                'Unable to submit the application. Please try again.';

            setError(
                typeof message === 'string'
                    ? message
                    : JSON.stringify(message)
            );
        } finally {
            setSubmitting(false);
        }
    }

    // Get student display name
    function getStudentName(student) {
    return (
        student.Name ||
        student.name ||
        student.full_name ||
        student.student_name ||
        student.user?.username ||
        student.user?.first_name ||
        `Student #${student.id}`
    );
}
    // Find student name for an application
    function getStudentNameById(id) {
        const student = students.find(
            (item) => String(item.id) === String(id)
        );

        return student
            ? getStudentName(student)
            : `Student #${id}`;
    }

    // Find job title for an application
    function getJobTitle(id) {
        const job = jobs.find(
            (item) => String(item.id) === String(id)
        );

        return job
            ? job.title || `Job #${job.id}`
            : `Job #${id}`;
    }

    // Style application status
    function getStatusClass(status) {
        const value = String(status || '').toLowerCase();

        if (value.includes('accept') || value.includes('select')) {
            return 'application-status application-status-success';
        }

        if (value.includes('reject')) {
            return 'application-status application-status-danger';
        }

        if (value.includes('pending') || value.includes('review')) {
            return 'application-status application-status-pending';
        }

        return 'application-status';
    }

    return (
        <div className="applications-page">
            <div className="applications-header">
                <div>
                    <h2>Applications Management</h2>
                    <p>
                        Submit and track student placement applications.
                    </p>
                </div>

                <button
                    type="button"
                    className="applications-refresh"
                    onClick={loadData}
                    disabled={loading}
                >
                    {loading ? 'Loading...' : 'Refresh'}
                </button>
            </div>

            {error && (
                <div className="applications-message applications-error">
                    {error}
                </div>
            )}

            {success && (
                <div className="applications-message applications-success">
                    {success}
                </div>
            )}

            {/* Apply for a job */}
            <section className="applications-card">
                <h3>Apply for a Job</h3>

                <form
                    className="applications-form"
                    onSubmit={handleSubmit}
                >
                    <div className="applications-field">
                        <label htmlFor="application-student">
                            Student
                        </label>

                        <select
                            id="application-student"
                            value={studentId}
                            onChange={(event) =>
                                setStudentId(event.target.value)
                            }
                            required
                        >
                            <option value="">Select student</option>

                            {students.map((student) => (
                                <option
                                    key={student.id}
                                    value={student.id}
                                >
                                    {getStudentName(student)}
                                    {' '}— ID: {student.id}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="applications-field">
                        <label htmlFor="application-job">
                            Job
                        </label>

                        <select
                            id="application-job"
                            value={jobId}
                            onChange={(event) =>
                                setJobId(event.target.value)
                            }
                            required
                        >
                            <option value="">Select job</option>

                            {jobs.map((job) => (
                                <option
                                    key={job.id}
                                    value={job.id}
                                >
                                    {job.title || `Job #${job.id}`}
                                    {' '}— ID: {job.id}
                                </option>
                            ))}
                        </select>
                    </div>

                    <button
                        type="submit"
                        className="applications-submit"
                        disabled={submitting || loading}
                    >
                        {submitting
                            ? 'Submitting...'
                            : 'Submit Application'}
                    </button>
                </form>
            </section>

            {/* Applications list */}
            <section className="applications-card">
                <div className="applications-list-header">
                    <div>
                        <h3>Placement Applications</h3>
                        <p>
                            Total applications: {applications.length}
                        </p>
                    </div>
                </div>

                {loading ? (
                    <p className="applications-empty">
                        Loading applications...
                    </p>
                ) : applications.length === 0 ? (
                    <p className="applications-empty">
                        No applications found.
                    </p>
                ) : (
                    <div className="applications-table-wrapper">
                        <table className="applications-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Student</th>
                                    <th>Job</th>
                                    <th>Status</th>
                                    <th>Applied At</th>
                                </tr>
                            </thead>

                            <tbody>
                                {applications.map((application) => (
                                    <tr key={application.id}>
                                        <td>#{application.id}</td>

                                        <td>
                                            {getStudentNameById(
                                                application.student
                                            )}
                                        </td>

                                        <td>
                                            {getJobTitle(application.job)}
                                        </td>

                                        <td>
                                            <span
                                                className={getStatusClass(
                                                    application.status
                                                )}
                                            >
                                                {application.status || 'Pending'}
                                            </span>
                                        </td>

                                        <td>
                                            {application.applied_at
                                                ? new Date(
                                                    application.applied_at
                                                ).toLocaleDateString()
                                                : '—'}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </section>
        </div>
    );
}

export default Applications;
