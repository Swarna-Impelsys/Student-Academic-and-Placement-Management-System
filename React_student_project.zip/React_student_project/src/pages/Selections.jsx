
import { useEffect, useState } from 'react';
import {
    getSelections,
    createSelection,
    updateSelection,
    deleteSelection,
} from '../services/selectionService';
import { getApplications } from '../services/applicationService';
import { getStudents } from '../services/studentService';
import { getJobs } from '../services/jobService';
import '../App.css';

const emptyForm = {
    application: '',
    status: 'pending',
    offer_date: '',
    joining_date: '',
    package: '',
    remarks: '',
};

function getList(data) {
    if (Array.isArray(data)) return data;
    return data?.results || data?.selections || data?.applications || data?.data || [];
}

function Selections() {
    const [selections, setSelections] = useState([]);
    const [applications, setApplications] = useState([]);
    const [students, setStudents] = useState([]);
    const [jobs, setJobs] = useState([]);
    const [form, setForm] = useState(emptyForm);
    const [editingId, setEditingId] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    async function loadData() {
        setLoading(true);
        setError('');

        try {
            const [selectionData, applicationData, studentData, jobData] =
                await Promise.all([
                    getSelections(),
                    getApplications(),
                    getStudents(),
                    getJobs(),
                ]);

            setSelections(getList(selectionData));
            setApplications(getList(applicationData));
            setStudents(getList(studentData));
            setJobs(getList(jobData));
        } catch (err) {
            console.error('Selection loading error:', err.response?.data || err);
            setError(
                err.response?.data?.detail ||
                err.response?.data?.error ||
                'Could not load selection data. Check your backend and login.'
            );
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        loadData();
    }, []);

    function handleChange(event) {
        const { name, value } = event.target;

        setForm((previous) => ({
            ...previous,
            [name]: value,
            ...(name === 'status' && value === 'rejected'
                ? { offer_date: '', joining_date: '', package: '' }
                : {}),
        }));
    }

    function resetForm() {
        setForm(emptyForm);
        setEditingId(null);
    }

    function getApplicationLabel(application) {
        const student = students.find(
            (item) => String(item.id) === String(application.student)
        );
        const job = jobs.find(
            (item) => String(item.id) === String(application.job)
        );

        const studentName =
            student?.Name || student?.name || `Student #${application.student}`;
        const jobTitle = job?.title || `Job #${application.job}`;

        return `${studentName} — ${jobTitle} (Application #${application.id})`;
    }

    function getApplicationDetails(applicationId) {
        const application = applications.find(
            (item) => String(item.id) === String(applicationId)
        );

        return application
            ? getApplicationLabel(application)
            : `Application #${applicationId ?? '—'}`;
    }

    async function handleSubmit(event) {
        event.preventDefault();
        setError('');
        setSuccess('');

        if (form.status === 'selected' && (!form.package || !form.joining_date)) {
            setError('A package and joining date are required for selected candidates.');
            return;
        }

        const payload = {
            application: Number(form.application),
            status: form.status,
            offer_date: form.offer_date || null,
            joining_date: form.joining_date || null,
            package: form.package === '' ? null : Number(form.package),
            remarks: form.remarks.trim(),
        };

        setSaving(true);

        try {
            if (editingId) {
                await updateSelection(editingId, payload);
                setSuccess('Selection record updated successfully.');
            } else {
                await createSelection(payload);
                setSuccess('Selection record created successfully.');
            }

            resetForm();
            await loadData();
        } catch (err) {
            console.error('Selection save error:', err.response?.data || err);
            const data = err.response?.data;

            setError(
                data
                    ? Object.entries(data)
                        .map(([field, messages]) =>
                            `${field}: ${
                                Array.isArray(messages)
                                    ? messages.join(', ')
                                    : typeof messages === 'object'
                                        ? JSON.stringify(messages)
                                        : messages
                            }`
                        )
                        .join(' | ')
                    : 'Could not save the selection record.'
            );
        } finally {
            setSaving(false);
        }
    }

    function startEdit(selection) {
        setEditingId(selection.id);
        setForm({
            application: String(selection.application ?? ''),
            status: selection.status || 'pending',
            offer_date: selection.offer_date || '',
            joining_date: selection.joining_date || '',
            package: selection.package ?? '',
            remarks: selection.remarks || '',
        });
        setError('');
        setSuccess('');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    async function handleDelete(id) {
        if (!window.confirm('Are you sure you want to delete this selection record?')) {
            return;
        }

        setError('');
        setSuccess('');

        try {
            await deleteSelection(id);
            setSuccess('Selection record deleted successfully.');

            if (editingId === id) resetForm();
            await loadData();
        } catch (err) {
            setError(
                err.response?.data?.detail ||
                err.response?.data?.error ||
                'Could not delete the selection record.'
            );
        }
    }

    return (
        <div className="selections-page">
            <div className="selections-header">
                <div>
                    <h2>Selection Management</h2>
                    <p>Record candidate selection decisions and offer details.</p>
                </div>

                <div className="selections-count">
                    <span>Total records</span>
                    <strong>{selections.length}</strong>
                </div>
            </div>

            {error && (
                <div className="selections-alert selections-error">{error}</div>
            )}

            {success && (
                <div className="selections-alert selections-success">{success}</div>
            )}

            <section className="selections-card">
                <h3>{editingId ? 'Edit Selection' : 'Record a Selection Decision'}</h3>

                <form className="selections-form" onSubmit={handleSubmit}>
                    <div className="selections-field selections-wide">
                        <label htmlFor="selection-application">Application</label>
                        <select
                            id="selection-application"
                            name="application"
                            value={form.application}
                            onChange={handleChange}
                            required
                        >
                            <option value="">Select an application</option>
                            {applications.map((application) => (
                                <option key={application.id} value={application.id}>
                                    {getApplicationLabel(application)}
                                </option>
                            ))}
                        </select>
                        {applications.length === 0 && (
                            <small>Create an application before recording a decision.</small>
                        )}
                    </div>

                    <div className="selections-field">
                        <label htmlFor="selection-status">Decision</label>
                        <select
                            id="selection-status"
                            name="status"
                            value={form.status}
                            onChange={handleChange}
                            required
                        >
                            <option value="pending">Pending</option>
                            <option value="selected">Selected</option>
                            <option value="rejected">Rejected</option>
                        </select>
                    </div>

                    {form.status !== 'rejected' && (
                        <>
                            <div className="selections-field">
                                <label htmlFor="selection-offer-date">Offer date</label>
                                <input
                                    id="selection-offer-date"
                                    name="offer_date"
                                    type="date"
                                    value={form.offer_date}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="selections-field">
                                <label htmlFor="selection-joining-date">Joining date</label>
                                <input
                                    id="selection-joining-date"
                                    name="joining_date"
                                    type="date"
                                    value={form.joining_date}
                                    onChange={handleChange}
                                    required={form.status === 'selected'}
                                />
                            </div>

                            <div className="selections-field">
                                <label htmlFor="selection-package">Package (annual)</label>
                                <input
                                    id="selection-package"
                                    name="package"
                                    type="number"
                                    min="0.01"
                                    step="0.01"
                                    placeholder="e.g. 600000"
                                    value={form.package}
                                    onChange={handleChange}
                                    required={form.status === 'selected'}
                                />
                            </div>
                        </>
                    )}

                    <div className="selections-field selections-wide">
                        <label htmlFor="selection-remarks">Remarks</label>
                        <textarea
                            id="selection-remarks"
                            name="remarks"
                            rows="3"
                            placeholder="Add decision notes or comments"
                            value={form.remarks}
                            onChange={handleChange}
                        />
                    </div>

                    <div className="selections-actions selections-wide">
                        <button type="submit" disabled={saving || applications.length === 0}>
                            {saving
                                ? 'Saving...'
                                : editingId
                                    ? 'Update Selection'
                                    : 'Save Decision'}
                        </button>

                        {editingId && (
                            <button
                                type="button"
                                className="selections-secondary"
                                onClick={resetForm}
                            >
                                Cancel Edit
                            </button>
                        )}
                    </div>
                </form>
            </section>

            <section className="selections-card">
                <div className="selections-list-header">
                    <h3>Selection Records</h3>
                    <button
                        type="button"
                        className="selections-secondary"
                        onClick={loadData}
                        disabled={loading}
                    >
                        Refresh
                    </button>
                </div>

                {loading ? (
                    <p className="selections-empty">Loading selection records...</p>
                ) : selections.length === 0 ? (
                    <p className="selections-empty">No selection records found.</p>
                ) : (
                    <div className="selections-table-wrap">
                        <table className="selections-table">
                            <thead>
                                <tr>
                                    <th>Application</th>
                                    <th>Decision</th>
                                    <th>Offer Date</th>
                                    <th>Joining Date</th>
                                    <th>Package</th>
                                    <th>Remarks</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {selections.map((selection) => (
                                    <tr key={selection.id}>
                                        <td>
                                            {getApplicationDetails(selection.application)}
                                        </td>
                                        <td>
                                            <span
                                                className={`selection-status selection-${selection.status}`}
                                            >
                                                {selection.status}
                                            </span>
                                        </td>
                                        <td>{selection.offer_date || '—'}</td>
                                        <td>{selection.joining_date || '—'}</td>
                                        <td>
                                            {selection.package != null
                                                ? Number(selection.package).toLocaleString()
                                                : '—'}
                                        </td>
                                        <td>{selection.remarks || '—'}</td>
                                        <td>
                                            <div className="selections-row-actions">
                                                <button
                                                    type="button"
                                                    onClick={() => startEdit(selection)}
                                                >
                                                    Edit
                                                </button>
                                                <button
                                                    type="button"
                                                    className="selections-delete"
                                                    onClick={() => handleDelete(selection.id)}
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </section>
        </div>
    );
}

export default Selections;
