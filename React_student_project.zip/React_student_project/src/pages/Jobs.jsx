import { useEffect, useState } from 'react';
import {
    getJobs,
    createJob,
    updateJob,
    deleteJob,
} from '../services/jobService';
import { getPlacementDrives } from '../services/placementDriveService';
import { getCourses, getSkills } from '../services/studentService';

const initialForm = {
    placement_drive: '',
    title: '',
    description: '',
    job_type: '',
    location: '',
    salary: '',
    vacancies: '1',
    minimum_age: '',
    minimum_marks: '',
    minimum_attendance: '',
    required_course: '',
    required_skills: [],
    maximum_backlogs: '0',
    is_active: true,
};

function Jobs() {
    const role = localStorage.getItem('role');
    const [jobs, setJobs] = useState([]);
    const [drives, setDrives] = useState([]);
    const [courses, setCourses] = useState([]);
    const [skills, setSkills] = useState([]);

    const [form, setForm] = useState(initialForm);
    const [editingId, setEditingId] = useState(null);

    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    useEffect(() => {
        loadData();
    }, []);

    async function loadData() {
        setLoading(true);
        setError('');

        try {
            const [jobData, driveData, courseData, skillData] =
                await Promise.all([
                    getJobs(),
                    getPlacementDrives(),
                    getCourses(),
                    getSkills(),
                ]);

            setJobs(
                Array.isArray(jobData)
                    ? jobData
                    : jobData.results || []
            );
            setDrives(
                Array.isArray(driveData)
                    ? driveData
                    : driveData.results || []
            );

            setCourses(
                Array.isArray(courseData)
                    ? courseData
                    : courseData.results || []
            );

            setSkills(
                Array.isArray(skillData)
                    ? skillData
                    : skillData.results || []
            );
        } catch (err) {
            setError(getErrorMessage(err));
        } finally {
            setLoading(false);
        }
    }

    function getErrorMessage(err) {
        const data = err.response?.data;

        if (!data) {
            return 'Unable to load or save jobs. Check your connection and API.';
        }

        if (typeof data === 'string') {
            return data;
        }

        return Object.entries(data)
            .map(([field, messages]) => {
                const message = Array.isArray(messages)
                    ? messages.join(', ')
                    : typeof messages === 'object'
                        ? JSON.stringify(messages)
                        : messages;

                return `${field}: ${message}`;
            })
            .join(' | ');
    }

    function handleChange(event) {
        const { name, value, type, checked } = event.target;

        setForm((previous) => ({
            ...previous,
            [name]: type === 'checkbox' ? checked : value,
        }));
    }

    function handleSkillChange(skillId, checked) {
        setForm((previous) => ({
            ...previous,
            required_skills: checked
                ? [...previous.required_skills, skillId]
                : previous.required_skills.filter(
                    (id) => id !== skillId
                ),
        }));
    }
    function resetForm() {
        setForm(initialForm);
        setEditingId(null);
        setError('');
        setSuccess('');
    }

    function startEdit(job) {
        setForm({
            placement_drive: String(job.placement_drive ?? ''),
            title: job.title || '',
            description: job.description || '',
            job_type: job.job_type || '',
            location: job.location || '',
            salary: String(job.salary ?? ''),
            vacancies: String(job.vacancies ?? 1),
            minimum_age: job.minimum_age ?? '',
            minimum_marks: job.minimum_marks ?? '',
            minimum_attendance: job.minimum_attendance ?? '',
            required_course: job.required_course
                ? String(job.required_course)
                : '',
            required_skills: (job.required_skills || []).map(
                (id) => Number(id)
            ),
            maximum_backlogs: String(job.maximum_backlogs ?? 0),
            is_active: job.is_active,
        });

        setEditingId(job.id);
        setError('');
        setSuccess('');

        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function validateForm() {
        if (Number(form.salary) <= 0) {
            return 'Salary must be greater than 0.';
        }

        if (
            !Number.isInteger(Number(form.vacancies)) ||
            Number(form.vacancies) <= 0
        ) {
            return 'Vacancies must be a positive whole number.';
        }

        if (
            form.minimum_age !== '' &&
            (!Number.isInteger(Number(form.minimum_age)) ||
                Number(form.minimum_age) <= 0)
        ) {
            return 'Minimum age must be a positive whole number.';
        }

        if (
            form.minimum_marks !== '' &&
            (Number(form.minimum_marks) < 0 ||
                Number(form.minimum_marks) > 100)
        ) {
            return 'Minimum marks must be between 0 and 100.';
        }

        if (
            form.minimum_attendance !== '' &&
            (Number(form.minimum_attendance) < 0 ||
                Number(form.minimum_attendance) > 100)
        ) {
            return 'Minimum attendance must be between 0 and 100.';
        }

        if (
            !Number.isInteger(Number(form.maximum_backlogs)) ||
            Number(form.maximum_backlogs) < 0
        ) {
            return 'Maximum backlogs must be zero or a positive whole number.';
        }

        if (form.title.trim().length < 3) {
            return 'Job title must contain at least 3 characters.';
        }

        return '';
    }

    function driveName(id) {
        if (!id) return '—';

        const drive = drives.find((item) => String(item.id) === String(id));
        return drive ? drive.name || drive.title || drive.company_name || 'Unknown Drive' : '—';
    }

    function courseName(id) {
        if (!id) return 'Any course';

        const course = courses.find((item) => String(item.id) === String(id));
        return course ? course.name || course.course_name || 'Unknown Course' : 'Any course';
    }

    function skillNames(ids = []) {
        if (!ids.length) return 'Any skill';

        return ids
            .map((id) => {
                const skill = skills.find((item) => String(item.id) === String(id));
                return skill ? skill.name || skill.skill_name : null;
            })
            .filter(Boolean)
            .join(', ') || 'Any skill';
    }

    async function handleSubmit(event) {
        event.preventDefault();

        const validationMessage = validateForm();
        if (validationMessage) {
            setError(validationMessage);
            setSuccess('');
            return;
        }

        setSaving(true);
        setError('');
        setSuccess('');

        try {
            const payload = {
                ...form,
                placement_drive: form.placement_drive ? Number(form.placement_drive) : null,
                salary: Number(form.salary),
                vacancies: Number(form.vacancies),
                minimum_age: form.minimum_age === '' ? null : Number(form.minimum_age),
                minimum_marks: form.minimum_marks === '' ? null : Number(form.minimum_marks),
                minimum_attendance: form.minimum_attendance === '' ? null : Number(form.minimum_attendance),
                required_course: form.required_course ? Number(form.required_course) : null,
                required_skills: form.required_skills.map(Number),
                maximum_backlogs: Number(form.maximum_backlogs),
            };

            if (editingId !== null) {
                await updateJob(editingId, payload);
            } else {
                await createJob(payload);
            }

            await loadData();
            resetForm();
            setSuccess(editingId !== null ? 'Job updated successfully.' : 'Job created successfully.');
        } catch (err) {
            setError(getErrorMessage(err));
        } finally {
            setSaving(false);
        }
    }

    async function handleDelete(job) {
        if (!window.confirm(`Delete job "${job.title}"?`)) {
            return;
        }

        try {
            await deleteJob(job.id);
            await loadData();
            setSuccess('Job deleted successfully.');
            setError('');
        } catch (err) {
            setError(getErrorMessage(err));
        }
    }

    return (
        <div className="management-page">
            <section className="management-card">
                <div className="card-heading">
                    <h3>{editingId !== null ? 'Edit Job' : 'Add New Job'}</h3>
                </div>

                {!['Admin', 'Teacher'].includes(role) ? (
                    <div className="empty-state">
                         Only Admins and Teachers can manage jobs.
                         </div>
                         ) : (
                    <form onSubmit={handleSubmit} className="job-form">
                        {error && <div className="alert alert-error">{error}</div>}
                        {success && <div className="alert alert-success">{success}</div>}

                        <div className="job-fields-grid">
                            <div className="form-field">
                                <label htmlFor="title">Job Title</label>
                                <input
                                    id="title"
                                    name="title"
                                    type="text"
                                    value={form.title}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="field-group">
                                <label htmlFor="placement_drive">Placement Drive</label>
                                <select
                                    id="placement_drive"
                                    name="placement_drive"
                                    value={form.placement_drive}
                                    onChange={handleChange}
                                >
                                    <option value="">Select drive</option>
                                    {drives.map((drive) => (
                                        <option key={drive.id} value={drive.id}>
                                            {drive.name || drive.title || drive.company_name || 'Drive'}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            <div className="field-group">
                                <label htmlFor="job_type">Job Type</label>
                                <select
                                    id="job_type"
                                    name="job_type"
                                    value={form.job_type}
                                    onChange={handleChange}
                                >
                                    <option value="">Select type</option>
                                    <option value="Full Time">Full Time</option>
                                    <option value="Part Time">Part Time</option>
                                    <option value="Internship">Internship</option>
                                    <option value="Contract">Contract</option>
                                </select>
                            </div>

                            <div className="field-group">
                                <label htmlFor="location">Location</label>
                                <input
                                    id="location"
                                    name="location"
                                    type="text"
                                    value={form.location}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="field-group">
                                <label htmlFor="salary">Salary</label>
                                <input
                                    id="salary"
                                    name="salary"
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    value={form.salary}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="field-group">
                                <label htmlFor="vacancies">Vacancies</label>
                                <input
                                    id="vacancies"
                                    name="vacancies"
                                    type="number"
                                    min="1"
                                    step="1"
                                    value={form.vacancies}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="field-group">
                                <label htmlFor="minimum_age">Minimum Age</label>
                                <input
                                    id="minimum_age"
                                    name="minimum_age"
                                    type="number"
                                    min="1"
                                    step="1"
                                    value={form.minimum_age}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="field-group">
                                <label htmlFor="minimum_marks">Minimum Marks</label>
                                <input
                                    id="minimum_marks"
                                    name="minimum_marks"
                                    type="number"
                                    min="0"
                                    max="100"
                                    step="1"
                                    value={form.minimum_marks}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="field-group">
                                <label htmlFor="minimum_attendance">Minimum Attendance</label>
                                <input
                                    id="minimum_attendance"
                                    name="minimum_attendance"
                                    type="number"
                                    min="0"
                                    max="100"
                                    step="1"
                                    value={form.minimum_attendance}
                                    onChange={handleChange}
                                />
                            </div>

                            <div className="field-group">
                                <label htmlFor="required_course">Required Course</label>
                                <select
                                    id="required_course"
                                    name="required_course"
                                    value={form.required_course}
                                    onChange={handleChange}
                                >
                                    <option value="">Any course</option>
                                    {courses.map((course) => (
                                        <option key={course.id} value={course.id}>
                                            {course.name || course.course_name || 'Course'}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            <div className="field-group">
                                <label htmlFor="maximum_backlogs">Maximum Backlogs</label>
                                <input
                                    id="maximum_backlogs"
                                    name="maximum_backlogs"
                                    type="number"
                                    min="0"
                                    step="1"
                                    value={form.maximum_backlogs}
                                    onChange={handleChange}
                                />
                            </div>
                        </div>

                        <div className="form-field job-skills-field">
                            <label>Required Skills</label>
                            <div className="checkbox-list">
                                {skills.map((skill) => (
                                    <label key={skill.id} className="checkbox-item">
                                        <input
                                            type="checkbox"
                                            checked={form.required_skills.includes(Number(skill.id))}
                                            onChange={(event) =>
                                                handleSkillChange(skill.id, event.target.checked)
                                            }
                                        />
                                        <span>{skill.name || skill.skill_name || 'Skill'}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div className="form-field job-description-field">
                            <label htmlFor="description">Description</label>
                            <textarea
                                id="description"
                                name="description"
                                rows="4"
                                value={form.description}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-field job-active-field">
                            <label>
                                <input
                                type="checkbox"
                                name="is_active"
                                checked={form.is_active}
                                onChange={handleChange}
                                />
                                <span>Active</span>
                                </label>
                                </div>

                        <div className="form-actions">
                            <button type="submit" className="btn btn-primary" disabled={saving}>
                                {saving
                                    ? 'Saving...'
                                    : editingId !== null
                                        ? 'Update Job'
                                        : 'Add Job'}
                            </button>

                            {editingId !== null && (
                                <button
                                    type="button"
                                    className="btn btn-secondary"
                                    onClick={resetForm}
                                    disabled={saving}
                                >
                                    Cancel
                                </button>
                            )}
                        </div>
                    </form>
                )}
            </section>

            <section className="management-card">
                <div className="card-heading">
                    <h3>Jobs</h3>
                </div>

                {loading ? (
                    <p>Loading jobs...</p>
                ) : jobs.length === 0 ? (
                    <div className="empty-state">No jobs found. Create your first job above.</div>
                ) : (
                    <div className="table-container">
                        <table className="management-table">
                            <thead>
                                <tr>
                                    <th>Job Title</th>
                                    <th>Placement Drive</th>
                                    <th>Type</th>
                                    <th>Location</th>
                                    <th>Salary</th>
                                    <th>Vacancies</th>
                                    <th>Required Course</th>
                                    <th>Required Skills</th>
                                    <th>Status</th>
                                    {['Admin', 'Teacher'].includes(role) && 
                                    <th>Actions</th>}
                                </tr>
                            </thead>

                            <tbody>
                                {jobs.map((job) => (
                                    <tr key={job.id}>
                                        <td>{job.title}</td>
                                        <td>{driveName(job.placement_drive)}</td>
                                        <td>{job.job_type}</td>
                                        <td>{job.location}</td>
                                        <td>
                                            {Number(job.salary).toLocaleString('en-IN', {
                                                minimumFractionDigits: 2,
                                                maximumFractionDigits: 2,
                                            })}
                                        </td>
                                        <td>{job.vacancies}</td>
                                        <td>{job.required_course ? courseName(job.required_course) : 'Any course'}</td>
                                        <td>{skillNames(job.required_skills)}</td>
                                        <td>
                                            <span
                                                className={
                                                    job.is_active
                                                        ? 'company-status active'
                                                        : 'company-status inactive'
                                                }
                                            >
                                                {job.is_active ? 'Active' : 'Inactive'}
                                            </span>
                                        </td>
                                        {['Admin', 'Teacher'].includes(role) && (
    <td>
        <div className="table-actions">
            <button
                type="button"
                className="btn btn-edit"
                onClick={() => startEdit(job)}
            >
                Edit
            </button>

            {role === 'Admin' && (
                <button
                    type="button"
                    className="btn btn-delete"
                    onClick={() => handleDelete(job)}
                >
                    Delete
                </button>
            )}
            </div>
            </td>
        )}
        </tr>
    ))}
    </tbody>
    </table>
    </div>
)}
 </section>
 </div>
 );
}

export default Jobs;
