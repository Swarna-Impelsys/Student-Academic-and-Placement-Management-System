import { useEffect, useState } from 'react';
import api from '../services/api';
import useApi from '../hooks/useApi';

function StudentDashboard() {
    const [dashboard, setDashboard] = useState(null);
    const { loading, error, execute } = useApi();

    useEffect(() => {
        async function fetchDashboard() {
            try {
                const response = await execute(() =>
                    api.get('student-dashboard/')
                );

                setDashboard(response.data);
            } catch (err) {
                // useApi already stores the error message.
                console.error('Failed to load student dashboard:', err);
            }
        }

        fetchDashboard();
    }, [execute]);

    if (loading) {
        return <p>Loading student dashboard...</p>;
    }

    if (error) {
        return <p role="alert">Error: {error}</p>;
    }

    if (!dashboard) {
        return <p>No dashboard data available.</p>;
    }

    const student = dashboard.student;
    const summary = dashboard.summary;

    return (
    <div className="student-dashboard">
        <header className="student-dashboard-header">
            <div>
                <p className="dashboard-eyebrow">ACADEMIC & PLACEMENT MANAGEMENT</p>
                <h1>Student Dashboard</h1>
                <p className="dashboard-welcome">
                    Welcome back, <strong>{student.Name}</strong>!
                </p>
            </div>
        </header>

        <section className="student-profile-card">
            <div className="student-avatar">
                {student.Name?.charAt(0).toUpperCase()}
            </div>

            <div className="student-profile-info">
                <h2>My Profile</h2>
                <p><strong>Name:</strong> {student.Name}</p>
                <p><strong>Email:</strong> {student.Email}</p>
                <p><strong>Course:</strong> {student.course_name}</p>
            </div>
        </section>

        <section className="student-summary-section">
            <h2>My Summary</h2>

            <div className="student-summary-grid">
                <div className="student-summary-card">
                    <span className="summary-icon">📚</span>
                    <p>Academic Records</p>
                    <h3>{summary.total_academic_records}</h3>
                </div>

                <div className="student-summary-card">
                    <span className="summary-icon">📄</span>
                    <p>Applications</p>
                    <h3>{summary.total_applications}</h3>
                </div>

                <div className="student-summary-card">
                    <span className="summary-icon">⏳</span>
                    <p>Pending Applications</p>
                    <h3>{summary.pending_applications}</h3>
                </div>

                <div className="student-summary-card">
                    <span className="summary-icon">🗓️</span>
                    <p>Interviews</p>
                    <h3>{summary.total_interviews}</h3>
                </div>

                <div className="student-summary-card">
                    <span className="summary-icon">🏆</span>
                    <p>Selections</p>
                    <h3>{summary.total_selections}</h3>
                </div>
            </div>
        </section>
    </div>
);
}

export default StudentDashboard;