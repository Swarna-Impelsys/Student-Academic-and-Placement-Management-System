
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { getStudents } from '../services/studentService';
import useApi from '../hooks/useApi';

function Students() {
    const [students, setStudents] = useState([]);

    const {
        loading,
        error,
        execute,
    } = useApi();

    async function loadStudents() {
        try {
            const data = await execute(() => getStudents());

            const studentList = Array.isArray(data)
                ? data
                : data.results ?? [];

            setStudents(studentList);
        } catch {
            // useApi handles and stores the error message.
        }
    }

    useEffect(() => {
        loadStudents();
    }, []);

    if (loading) {
        return (
            <div>
                <h2>Students</h2>
                <p>Loading students...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div>
                <h2>Students</h2>

                <p className="login-error" role="alert">
                    {error}
                </p>

                <button
                    type="button"
                    className="btn btn-primary"
                    onClick={loadStudents}
                >
                    Retry
                </button>
            </div>
        );
    }

    return (
        <div>
            <h2>Students</h2>

            <Link
                to="/students/add"
                className="btn btn-primary"
            >
                + Add Student
            </Link>

            {students.length === 0 ? (
                <p>No students found.</p>
            ) : (
                <div className="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Age</th>
                                <th>Phone</th>
                                <th>Status</th>
                            </tr>
                        </thead>

                        <tbody>
                            {students.map((student) => (
                                <tr key={student.id}>
                                    <td>{student.id}</td>

                                    <td>
                                        <Link
                                            to={`/students/${student.id}`}
                                        >
                                            {student.Name || '—'}
                                        </Link>
                                    </td>

                                    <td>{student.Email || '—'}</td>

                                    <td>{student.Age ?? '—'}</td>

                                    <td>{student.Phone || '—'}</td>

                                    <td>
                                        {student.status_display ||
                                            student.status ||
                                            '—'}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}

export default Students;
