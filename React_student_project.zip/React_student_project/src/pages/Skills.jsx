
import { useEffect, useState } from 'react';
import {
    getSkills,
    createSkill,
    updateSkill,
    deleteSkill
} from '../services/studentService';

function Skills() {
    const [skills, setSkills] = useState([]);
    const [name, setName] = useState('');
    const [editingId, setEditingId] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    async function loadSkills() {
        try {
            setLoading(true);
            setError('');

            const data = await getSkills();
            setSkills(Array.isArray(data) ? data : data.results ?? []);
        } catch (err) {
            setError(
                err.response?.data?.detail ||
                'Unable to load skills. Check your permissions and API server.'
            );
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        loadSkills();
    }, []);

    function startEdit(skill) {
        setEditingId(skill.id);
        setName(skill.name);
        setError('');
        setSuccess('');
    }

    function cancelEdit() {
        setEditingId(null);
        setName('');
        setError('');
    }

    async function handleSubmit(event) {
        event.preventDefault();
        setError('');
        setSuccess('');

        const trimmedName = name.trim();

        if (trimmedName.length < 2) {
            setError('Skill name must contain at least 2 characters.');
            return;
        }

        try {
            setSaving(true);

            if (editingId !== null) {
                await updateSkill(editingId, { name: trimmedName });
                setSuccess('Skill updated successfully.');
            } else {
                await createSkill({ name: trimmedName });
                setSuccess('Skill added successfully.');
            }

            setName('');
            setEditingId(null);
            await loadSkills();
        } catch (err) {
            const data = err.response?.data;
            setError(
                data?.name?.[0] ||
                data?.detail ||
                data?.error ||
                'Unable to save skill. You may not have permission.'
            );
        } finally {
            setSaving(false);
        }
    }

    async function handleDelete(skill) {
        if (!window.confirm(`Delete the skill "${skill.name}"?`)) {
            return;
        }

        setError('');
        setSuccess('');

        try {
            await deleteSkill(skill.id);
            setSuccess('Skill deleted successfully.');
            await loadSkills();
        } catch (err) {
            setError(
                err.response?.data?.detail ||
                'Unable to delete skill. Check your permissions.'
            );
        }
    }

return (
    <div className="management-page">
        <div className="management-header">
            <div>
                <h2>Skills Management</h2>
                <p>Manage the skills available in Student PMS.</p>
            </div>

            <div className="skills-count">
                <span>Total Skills</span>
                <strong>{skills.length}</strong>
            </div>
        </div>

        {error && <div className="alert alert-error">{error}</div>}
        {success && <div className="alert alert-success">{success}</div>}

        <section className="management-card">
            <div className="card-heading">
                <div>
                    <h3>{editingId !== null ? 'Edit Skill' : 'Add Skill'}</h3>
                    <p>Enter a skill name to add it to the system.</p>
                </div>
            </div>

            <form className="skill-form" onSubmit={handleSubmit}>
                <div className="form-field">
                    <label htmlFor="skill-name">Skill Name</label>
                    <input
                        id="skill-name"
                        type="text"
                        value={name}
                        onChange={(event) => setName(event.target.value)}
                        placeholder="e.g. Python, React, SQL"
                        minLength={2}
                        required
                    />
                </div>

                <div className="form-actions">
                    <button
                        type="submit"
                        className="btn btn-primary"
                        disabled={saving}
                    >
                        {saving
                            ? 'Saving...'
                            : editingId !== null
                                ? 'Update Skill'
                                : 'Add Skill'}
                    </button>

                    {editingId !== null && (
                        <button
                            type="button"
                            className="btn btn-secondary"
                            onClick={cancelEdit}
                        >
                            Cancel
                        </button>
                    )}
                </div>
            </form>
        </section>

        <section className="management-card">
            <div className="card-heading">
                <div>
                    <h3>Available Skills</h3>
                    <p>View and manage all registered skills.</p>
                </div>
                <span className="record-count">
                    {skills.length} skills
                </span>
            </div>

            {loading ? (
                <p className="empty-state">Loading skills...</p>
            ) : skills.length === 0 ? (
                <div className="empty-state">No skills found. Add your first skill above.</div>
            ) : (
                <div className="table-container">
                    <table className="management-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Skill Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {skills.map((skill) => (
                                <tr key={skill.id}>
                                    <td className="skill-id">#{skill.id}</td>
                                    <td>
                                        <span className="skill-name">
                                            {skill.name}
                                        </span>
                                    </td>
                                    <td>
                                        <div className="table-actions">
                                            <button
                                                type="button"
                                                className="btn btn-edit"
                                                onClick={() => startEdit(skill)}
                                            >
                                                Edit
                                            </button>
                                            <button
                                                type="button"
                                                className="btn btn-delete"
                                                onClick={() => handleDelete(skill)}
                                            >
                                                Delete
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </section>
    </div>
);
}
export default Skills;
