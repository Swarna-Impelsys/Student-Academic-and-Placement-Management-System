
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { logoutUser } from '../services/logoutService';

function Layout() {
    const role = localStorage.getItem('role');
    const navigate = useNavigate();

    async function handleLogout() {
        const refreshToken = localStorage.getItem('refreshToken');

        try {
            await logoutUser(refreshToken);
        } finally {
            navigate('/login', { replace: true });
        }
    }

    return (
        <div className="layout">
            <aside className="sidebar">
                <h2>Student PMS</h2>

                <nav>
                    <NavLink to="/">Dashboard</NavLink>
                    {role?.toLowerCase() === 'student' && (
                        <NavLink to="/subject-selection">
                            Subject Selection
                            </NavLink>
                        )}
                    {(role === 'Admin' || role === 'Teacher') && (
                        <NavLink to="/students">Students</NavLink>
                        )}
                    <NavLink to="/academic-records">
                        Academic Records
                    </NavLink>
                    <NavLink to="/jobs">Jobs</NavLink>
                    <NavLink to="/applications">Applications</NavLink>
                    <NavLink to="/skills">Skills</NavLink>
                    <NavLink to="/certifications">Certifications</NavLink>
                    {role === 'Admin' && (
                        <NavLink to="/companies">Companies</NavLink>
                        )}
                    {role === 'Admin' && (
                        <NavLink to="/subject-configuration">
                             Subject Configuration
                              </NavLink>
                            )}
                    <NavLink to="/placement-drives">Placement Drives</NavLink>
                    <NavLink to="/eligibility">Eligibility Engine</NavLink>
                    <NavLink to="/interviews">Interviews</NavLink>
                    <NavLink to="/selections">Selections</NavLink>
                </nav>

                <button
                    type="button"
                    className="btn btn-primary"
                    onClick={handleLogout}
                >
                    Logout
                </button>
            </aside>

            <div className="main-area">
                <header className="topbar">
                    <h1>Academic & Placement Management</h1>
                </header>

                <main className="page-content">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}

export default Layout;
