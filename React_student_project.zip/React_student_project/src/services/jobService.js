
import api from './api';

export const getJobs = async () => {
    const response = await api.get('jobs/');
    return response.data;
};

export const createJob = async (data) => {
    const response = await api.post('jobs/', data);
    return response.data;
};

export const updateJob = async (id, data) => {
    const response = await api.patch(`jobs/${id}/`, data);
    return response.data;
};

export const deleteJob = async (id) => {
    const response = await api.delete(`jobs/${id}/`);
    return response.data;
};
