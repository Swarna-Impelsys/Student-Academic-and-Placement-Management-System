
import api from './api';

// Get all applications
export const getApplications = async () => {
    const response = await api.get('applications/');
    return response.data;
};

// Apply for a job
export const createApplication = async (studentId, jobId) => {
    const response = await api.post('applications/', {
        student: Number(studentId),
        job: Number(jobId),
    });

    return response.data;
};
